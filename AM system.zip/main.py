import cmath
import requests

def pokemon():
    base_url = 'https://pokeapi.co/api/v2/'

    def get_pokemon_data(name):
        url = (f'{base_url}pokemon/{name}')
        response = requests.get(url)
        print(response)
        if response.status_code == 200:
            poke_data = response.json()
            return poke_data
        else:
            print(f'error {response.status_code}')

    name = input('whats your pokemon name: ')
    poke_info = get_pokemon_data(name)

    if poke_info:
        print(f'Name: {poke_info["name"]}')
        print(f'Height: {poke_info["height"]} feet')
        print(f'Weight: {poke_info["weight"]} pounds')
        print(f'type: {poke_info["types"]}')

def banking_system():
    while True:
        name = input("What's the account name: ")
        age = float(input("Please input your age: "))
        total = float(input("Please insert balance: "))

        while True:
            operation = input("What is your operation (deposit, withdraw, account info): ").lower()

            if operation == "deposit":
                print("/////////////////////////////////////////////////////")
                deposit_add = float(input("How much would you like to deposit: "))
                total += deposit_add
                print(f"Your total is: ${total:.2f}")

            elif operation == "withdraw":
                withdraw_sub = float(input("How much would you like to withdraw: "))
                if withdraw_sub > total:
                    print("Not enough funds")
                else:
                    total -= withdraw_sub
                    print(f"Your total is: ${total:.2f}")

            elif operation == "account info":
                print(f"Name: {name}, Age: {age}, Total balance: ${total:.2f}")

            else:
                print("Please input a valid operation.")
                continue

            program = input("Would you like to continue? Type 'yes'                  to continue or 'end' to exit: ").lower()
            if program == "end":
                print("Goodbye!")
                return

def calculator():
    print('This calculator can perform the following operations:')
    print('add, subtract, multiply, divide, quadratic roots, square roots')

    operation = input('Please input your operation: ')

    def operations(operation):
        if operation == "add":
            x = float(input('Enter the first number: '))
            y = float(input('Enter the second number: '))
            return x + y

        elif operation == "subtract":
            x = float(input('Enter the first number: '))
            y = float(input('Enter the second number: '))
            return x - y

        elif operation == "multiply":
            x = float(input('Enter the first number: '))
            y = float(input('Enter the second number: '))
            return x * y

        elif operation == "divide":
            x = float(input('Enter the first number: '))
            y = float(input('Enter the second number: '))
            return x / y

        elif operation == "quadratic roots":
            print("For this function, please input the coefficients A, B, and C.")
            a = float(input('Enter the coefficient A: '))
            b = float(input('Enter the coefficient B: '))
            c = float(input('Enter the coefficient C: '))

            dis = b ** 2 - 4 * a * c

            root1 = (-b + cmath.sqrt(dis)) / (2 * a)
            root2 = (-b - cmath.sqrt(dis)) / (2 * a)

            if root1.imag == 0:
                root1 = root1.real

            if root2.imag == 0:
                root2 = root2.real

            print("\nThe solutions to the quadratic equation are:")
            print(f"Root 1: {root1}")
            print(f"Root 2: {root2}")
            return None

        elif operation == "square root":
            x = float(input('Enter the number: '))
            return cmath.sqrt(x).real

        else:
            return "Invalid operation. Please try again."

    result = operations(operation)

    if result is not None:
        print(f'The result is: {result}')






#ui sytem /////////////////////////////////////////////////////////

print('this is personal os system')
print('all credit is given to the creator of this system'')
modual = input('what modual would you like to use: ')

if modual == 'banking system':
    banking_system()

elif modual == 'pokemon':
    pokemon()
    
elif modual == 'calculator':
    calculator()

else:
    print('that is not a modual')

